//---------------------------------------------------------------------------

#ifndef signaltestH
#define signaltestH



adjust_zx (char *f_out);
adjust_cpc(char *f_out);
adjust_msx(char *f_out);
adjust_81 (char *f_out);

//---------------------------------------------------------------------------
#endif
