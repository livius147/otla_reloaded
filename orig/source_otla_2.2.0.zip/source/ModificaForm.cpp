//---------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "ModificaForm.h"
//--------------------------------------------------------------------- 
#pragma resource "*.dfm"
TModificaDlg *ModificaDlg;
//---------------------------------------------------------------------
__fastcall TModificaDlg::TModificaDlg(TComponent* AOwner)
	: TForm(AOwner)
{
}
//---------------------------------------------------------------------
