PROYECTO OTLA

Executable otla.exe converts files from computers zx81, ZX Spectrum, Amstrad CPC and MSX to audio files to be loaded into computers via input cassette.

See more information in wiki otla project. http://code.google.com/p/otla/w/list


Acknowledgments
Antonio Villena for his ultracargas that represented a quantum leap in the state of the art of loads at high speed
McLeod/Ideafix for his aportation to operate with modern audio sampling frequency of 48000 Hz
Zyloj for his test on real Spectrum and his interest in defining a standard high-speed load
Artaburu for his help on  Amstrad issues and patient work as betatester on a real Amstrad 464
WYZ for their help on msx and test on real MSX
Xavier Arb�s for betatesting, XAvSnap and siggi for technical aid and BrunoFlorindo for encouraging on adaptation to zx81
And so many people who showed their enthuasiasm  and use fast loads on their old computers, especially those who have come to read this far.