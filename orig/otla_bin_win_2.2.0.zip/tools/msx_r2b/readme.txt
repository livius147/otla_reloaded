

________________________________________
MSXR2B
MSX ROM to Binaries
msx@dlcsistemas.com
http://www.dlcsistemas.com/msx
JJC Software




________________________________________
How to install

Just copy the provided files into any directory



________________________________________
What does this utility


This util converts MSX ROM files of 8Kb, 16Kb and 32Kb into binary loadable files

The format of the command is

MSXR2B romfile.rom 

The romfile.rom must exist and it's checked to see if it's a really
rom file.
Then, depending of the size, one or two binary files will be created.

For 8 and 16Kb ROM:

* It's created a file with the same name but the .BIN extension at the working dir.

For 32Kb ROM:

* Two files will be created, by appending an "1" and "2" and the trailing .BIN to
  the name of the file

The created files can be loaded as a binary files and executed by doing

BLOAD"name1.bin",R: BLOAD"name2.bin",R

________________________________________
Some samples

* A 16Kb ROM

Guess that we have the 16Kb ROM on the file MYGAME.ROM 
Then put MSXR2B MYGAME.ROM and the file MYGAME.BIN will be generated.

Just add this file to the disk you want and you can exec it on your preferred
emulator or MSX with disk by doing BLOAD"MYGAME.BIN",R

If you have an MSX with tape, convert this file into .WAV one by using MSXF2W
and load it from the cassette by doing BLOAD"CAS:",R

* A 32Kb ROM

Guess that we have the 32Kb ROM on the file GREAT.ROM 
Then put MSXR2B GREAT.ROM and the files GREAT1.BIN and GREAT2.BIN will be generated.

Add these files to the disk you want and you can exec the rom on your preferred
emulator or MSX with disk by doing 

POKE -1,170
BLOAD"GREAT1.BIN",R:BLOAD"GREAT2.BIN",R

If you have an MSX with tape, convert these two files into .WAV one by using MSXF2W
and load each of them from the cassette by doing 

POKE -1,170
BLOAD"CAS:",R:BLOAD"CAS:",R

________________________________________
Notes about MSXR2B


This utility is an MS-DOS PC program and it's written in C 
and ready to run even on i8086's

It gets any ROM up to 32Kb and places code to load the data when executed in the 
correct RAM slots.

If a 32Kb ROM is got, then the program splits the ROM into 2 x 16Kb files.

This program, in conjunction with the MSXF2W one, are great because they do easy
to get ROM files on PC's and exec into an MSX1 with tape connector.

A sample of this could be:

MSXR2B GAME.ROM
MSXF2W GAME.BIN GAME.WAV

Here you have the game inside an image tape, ready to play and get by the MSX1


________________________________________
Limitations

Now is corrected a bug when using MSX with built-in programs on startup (i.e. Sony Hitbit)


________________________________________
Notice

MSXR2B
MSX ROM to Binaries
msx@dlcsistemas.com
http://www.dlcsistemas.com/msx
JJC Software

BY USING THIS SOFTWARE YOU ARE CONSENTING TO BE BOUND BY THIS 
AGREEMENT.

MSXR2B is a free software.
MSXR2B may be freely distributed and used subject to the following 
terms:

* You may NOT modify or translate the executable files or help 
  files provided.
* You may NOT sell this software. This utility is free.
* You may NOT distribute MSXR2B as a part of any commercial package.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY. Under no circumstances and under no legal 
theory, contract or otherwise shall JJC Software or the author be 
liable to you or any other person for any indirect, special, 
incidental or consequential damages of any character. There is no 
warranty for damages of any type caused by using this application. 

You may find the latest version of MSXR2B at JJC Software home page:
http://www.dlcsistemas.com/msx

Feel free to tell what you think about the program to the author.
Comments and Suggestions are well appreciated.

You can contact the author by email :  msx@dlcsistemas.com
